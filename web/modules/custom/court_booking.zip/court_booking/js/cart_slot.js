/**
 * @file
 * Cart: edit BAT lesson slot (modal + availability + POST update).
 */
(function (Drupal, drupalSettings, once) {
  'use strict';

  function ymdInZone(iso, timeZone) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(new Date(iso));
    const y = parts.find((p) => p.type === 'year')?.value;
    const m = parts.find((p) => p.type === 'month')?.value;
    const d = parts.find((p) => p.type === 'day')?.value;
    return `${y}-${m}-${d}`;
  }

  function parseHmMinutes(hm) {
    const raw = String(hm || '').trim();
    if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(raw)) {
      return null;
    }
    const [h, min] = raw.split(':').map((x) => parseInt(x, 10));
    return h * 60 + min;
  }

  function minutesSinceMidnightInZone(iso, timeZone) {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).formatToParts(new Date(iso));
    const h = parseInt(parts.find((p) => p.type === 'hour')?.value || '0', 10);
    const min = parseInt(parts.find((p) => p.type === 'minute')?.value || '0', 10);
    return h * 60 + min;
  }

  function isEntrySelectable(entry) {
    if (!entry) {
      return false;
    }
    if (entry.status === 'closed' || entry.booking_window_exceeded) {
      return false;
    }
    return entry.status === 'available' && Number(entry.remaining) > 0;
  }

  function normalizeDrupalTimeZoneId(raw) {
    const str = typeof raw === 'string' ? raw.trim() : '';
    if (!str) {
      return '';
    }
    try {
      Intl.DateTimeFormat(undefined, { timeZone: str }).format(0);
      return str;
    } catch (e) {
      return '';
    }
  }

  function calendarEntries(cal) {
    if (!cal || typeof cal !== 'object') {
      return [];
    }
    return Object.values(cal);
  }

  function formatMonthYearHeading(ymd, tz) {
    const [y, m, d] = ymd.split('-').map((x) => parseInt(x, 10));
    const utcNoon = Date.UTC(y, m - 1, d, 12, 0, 0);
    return new Intl.DateTimeFormat(undefined, {
      timeZone: tz,
      month: 'short',
      year: 'numeric',
    }).format(new Date(utcNoon));
  }

  function slotCountForVariation(v, slotMinutesDefault, durationHours) {
    const slotLen = Math.max(1, Number(v.slotMinutes) || slotMinutesDefault);
    const totalMin = durationHours * 60;
    if (totalMin % slotLen !== 0) {
      return null;
    }
    return totalMin / slotLen;
  }

  function consecutiveBlock(cal, startIso, slotCount) {
    let cur = startIso;
    let lastEnd = null;
    for (let i = 0; i < slotCount; i++) {
      const entry = calendarEntries(cal).find((e) => e.start === cur);
      if (!entry || !isEntrySelectable(entry)) {
        return null;
      }
      lastEnd = entry.end;
      cur = entry.end;
    }
    return lastEnd ? { start: startIso, end: lastEnd } : null;
  }

  function pillClasses(on, disabled) {
    const base =
      'rounded-full border px-4 py-2 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E] focus-visible:ring-offset-2';
    if (disabled) {
      return `${base} cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400`;
    }
    if (on) {
      return `${base} border-[#02216E] bg-[#02216E] text-white`;
    }
    return `${base} border-slate-300 bg-white text-slate-800 hover:border-[#02216E]`;
  }

  Drupal.behaviors.courtBookingCartSlot = {
    attach(context) {
      const s = drupalSettings.courtBookingCart;
      if (!s || !Array.isArray(s.dates) || !s.variationsById) {
        return;
      }

      once('court-booking-cart-slot', 'body', context).forEach(() => {
        const siteTimeZoneId = normalizeDrupalTimeZoneId(s.timezone) || 'UTC';
        const slotMinutesDefault = Math.max(1, parseInt(String(s.slotMinutes || 60), 10));
        const maxBookingHours = Math.max(1, Math.min(24, parseInt(String(s.maxBookingHours || 4), 10)));
        const dates = s.dates;
        const bookableYmd = new Set(dates.map((d) => d.ymd));
        const variationsById = s.variationsById;

        let modalRoot = null;
        let focusBefore = null;
        let ctx = {
          orderItemId: '',
          variation: null,
          selectedYmd: null,
          selectedDay: null,
          selectedStartIso: null,
          selectedBlock: null,
          calendars: null,
          visibleYm: '',
          durationHours: 1,
        };

        function ensureModal() {
          if (modalRoot) {
            return modalRoot;
          }
          modalRoot = document.createElement('div');
          modalRoot.id = 'cb-cart-slot-modal';
          modalRoot.className = 'fixed inset-0 z-50 hidden';
          modalRoot.innerHTML = `
<div class="absolute inset-0 bg-slate-900/50" data-cb-cart-backdrop></div>
<div class="absolute inset-0 flex items-end justify-center p-4 sm:items-center" role="presentation">
  <div class="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white shadow-xl" role="dialog" aria-modal="true" aria-labelledby="cb-cart-slot-title" data-cb-cart-dialog>
    <div class="border-b border-slate-100 px-5 py-4 flex items-start justify-between gap-3">
      <h2 id="cb-cart-slot-title" class="font-display text-lg font-semibold text-slate-900">${Drupal.checkPlain(Drupal.t('Change date and time'))}</h2>
      <button type="button" class="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-800" data-cb-cart-close aria-label="${Drupal.checkPlain(Drupal.t('Close'))}">✕</button>
    </div>
    <div class="px-5 py-4 space-y-4">
      <p class="text-center text-sm font-semibold uppercase tracking-wide text-slate-500" data-cb-cart-month></p>
      <div class="flex items-center justify-between gap-2">
        <button type="button" class="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 hover:border-[#02216E]" data-cb-strip-prev>${Drupal.checkPlain(Drupal.t('Prev'))}</button>
        <button type="button" class="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 hover:border-[#02216E]" data-cb-strip-next>${Drupal.checkPlain(Drupal.t('Next'))}</button>
      </div>
      <div class="flex gap-2 overflow-x-auto pb-1" role="list" data-cb-cart-dates></div>
      <div>
        <label class="mb-1 block text-xs font-semibold uppercase text-slate-500" for="cb-cart-duration">${Drupal.checkPlain(Drupal.t('Duration'))}</label>
        <select id="cb-cart-duration" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" data-cb-cart-duration></select>
      </div>
      <div class="flex flex-wrap gap-2" role="list" data-cb-cart-times></div>
      <p class="text-sm text-amber-700 min-h-[1.25rem]" data-cb-cart-status></p>
      <div class="flex gap-3 pt-2">
        <button type="button" class="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50" data-cb-cart-cancel>${Drupal.checkPlain(Drupal.t('Cancel'))}</button>
        <button type="button" class="flex-1 rounded-xl bg-[#02216E] py-3 text-sm font-semibold text-white hover:bg-[#011550] disabled:opacity-50" data-cb-cart-save disabled>${Drupal.checkPlain(Drupal.t('Update'))}</button>
      </div>
    </div>
  </div>
</div>`;
          document.body.appendChild(modalRoot);

          modalRoot.querySelector('[data-cb-cart-backdrop]').addEventListener('click', closeModal);
          modalRoot.querySelector('[data-cb-cart-close]').addEventListener('click', closeModal);
          modalRoot.querySelector('[data-cb-cart-cancel]').addEventListener('click', closeModal);
          modalRoot.querySelector('[data-cb-cart-save]').addEventListener('click', onSave);
          modalRoot.querySelector('[data-cb-strip-prev]').addEventListener('click', () => shiftMonth(-1));
          modalRoot.querySelector('[data-cb-strip-next]').addEventListener('click', () => shiftMonth(1));
          modalRoot.querySelector('[data-cb-cart-duration]').addEventListener('change', () => {
            ctx.durationHours = Math.max(1, parseInt(modalRoot.querySelector('[data-cb-cart-duration]').value, 10) || 1);
            ctx.selectedStartIso = null;
            ctx.selectedBlock = null;
            renderTimes();
            updateSaveState();
          });

          document.addEventListener('keydown', onKeydown);
          return modalRoot;
        }

        function onKeydown(e) {
          if (!modalRoot || modalRoot.classList.contains('hidden')) {
            return;
          }
          if (e.key === 'Escape') {
            e.preventDefault();
            closeModal();
          }
        }

        function closeModal() {
          if (!modalRoot) {
            return;
          }
          modalRoot.classList.add('hidden');
          if (focusBefore) {
            focusBefore.focus();
            focusBefore = null;
          }
        }

        function openModal() {
          const m = ensureModal();
          m.classList.remove('hidden');
          focusBefore = document.activeElement;
          const dlg = m.querySelector('[data-cb-cart-dialog]');
          const fe = dlg.querySelector('button, [href], select, input, textarea, [tabindex]:not([tabindex="-1"])');
          if (fe) {
            fe.focus();
          }
        }

        function shiftMonth(delta) {
          if (!ctx.visibleYm) {
            return;
          }
          const [y, mo] = ctx.visibleYm.split('-').map((x) => parseInt(x, 10));
          const d = new Date(Date.UTC(y, mo - 1 + delta, 1));
          ctx.visibleYm = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
          renderDateStrip();
        }

        function populateDurationSelect() {
          const el = modalRoot.querySelector('[data-cb-cart-duration]');
          el.innerHTML = '';
          for (let h = 1; h <= maxBookingHours; h++) {
            const opt = document.createElement('option');
            opt.value = String(h);
            opt.textContent = h === 1 ? Drupal.t('1 Hour') : Drupal.t('@n Hours', { '@n': String(h) });
            el.appendChild(opt);
          }
        }

        function daysInVisibleMonth() {
          return dates.filter((d) => d.ymd.slice(0, 7) === ctx.visibleYm);
        }

        function renderDateStrip() {
          const elDates = modalRoot.querySelector('[data-cb-cart-dates]');
          const elMonth = modalRoot.querySelector('[data-cb-cart-month]');
          elDates.innerHTML = '';
          if (ctx.selectedYmd) {
            elMonth.textContent = formatMonthYearHeading(ctx.selectedYmd, siteTimeZoneId).toUpperCase();
          } else if (ctx.visibleYm) {
            elMonth.textContent = formatMonthYearHeading(`${ctx.visibleYm}-01`, siteTimeZoneId).toUpperCase();
          }
          if (!ctx.visibleYm && dates.length) {
            ctx.visibleYm = dates[0].ymd.slice(0, 7);
          }
          const slice = daysInVisibleMonth();
          slice.forEach((day) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.dataset.ymd = day.ymd;
            const on = day.ymd === ctx.selectedYmd;
            btn.className = on
              ? 'min-w-[4.5rem] shrink-0 rounded-xl border-2 border-[#02216E] bg-[#02216E] px-3 py-3 text-center text-white shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]'
              : 'min-w-[4.5rem] shrink-0 rounded-xl border border-slate-200 bg-white px-3 py-3 text-center text-slate-800 shadow-sm hover:border-[#02216E] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]';
            btn.innerHTML = `<span class="block text-xs font-medium uppercase ${on ? 'text-white' : 'text-slate-500'}">${Drupal.checkPlain(
              day.weekday || '',
            )}</span><span class="mt-1 block font-display text-lg font-semibold">${Drupal.checkPlain(String(day.dayNum || ''))}</span>`;
            btn.addEventListener('click', () => selectDay(day));
            elDates.appendChild(btn);
          });
        }

        function selectDay(day) {
          if (!day) {
            return;
          }
          ctx.selectedYmd = day.ymd;
          ctx.selectedDay = { ymd: day.ymd, from: day.from, to: day.to };
          ctx.visibleYm = day.ymd.slice(0, 7);
          ctx.selectedStartIso = null;
          ctx.selectedBlock = null;
          renderDateStrip();
          loadDayData();
          updateSaveState();
        }

        async function fetchCalendar(vid, fromIso, toIso) {
          const interval = encodeURIComponent(s.slotInterval || 'PT60M');
          const url = `${Drupal.url(`commerce-bat/availability/${vid}`)}?from=${encodeURIComponent(
            fromIso,
          )}&to=${encodeURIComponent(toIso)}&interval=${interval}`;
          const res = await fetch(url, { credentials: 'same-origin' });
          if (!res.ok) {
            throw new Error(`Availability HTTP ${res.status}`);
          }
          return res.json();
        }

        async function loadDayData() {
          const elStatus = modalRoot.querySelector('[data-cb-cart-status]');
          if (!ctx.variation || !ctx.selectedDay) {
            return;
          }
          elStatus.textContent = Drupal.t('Loading availability…');
          modalRoot.querySelector('[data-cb-cart-times]').innerHTML = '';
          try {
            const cal = await fetchCalendar(ctx.variation.id, ctx.selectedDay.from, ctx.selectedDay.to);
            ctx.calendars = { [String(ctx.variation.id)]: cal };
            renderTimes();
            elStatus.textContent = '';
          } catch (e) {
            elStatus.textContent = Drupal.t('Could not load availability. Please refresh.');
            // eslint-disable-next-line no-console
            console.error(e);
          }
        }

        function renderTimes() {
          const elTimes = modalRoot.querySelector('[data-cb-cart-times]');
          elTimes.innerHTML = '';
          if (!ctx.calendars || !ctx.selectedYmd || !ctx.variation) {
            return;
          }
          const tz = siteTimeZoneId;
          const vid = String(ctx.variation.id);
          const cal = ctx.calendars[vid];
          const byStart = new Map();
          calendarEntries(cal).forEach((entry) => {
            if (!entry.start) {
              return;
            }
            if (ymdInZone(entry.start, tz) !== ctx.selectedYmd) {
              return;
            }
            if (!byStart.has(entry.start)) {
              byStart.set(entry.start, []);
            }
            byStart.get(entry.start).push({ entry });
          });
          const times = Array.from(byStart.keys()).sort();
          const openM = parseHmMinutes(s.bookingDayStart);
          const closeM = parseHmMinutes(s.bookingDayEnd);
          const hasWindow = openM !== null && closeM !== null && closeM > openM;
          const v = ctx.variation;
          const n = slotCountForVariation(v, slotMinutesDefault, ctx.durationHours);
          const timesOk = times.filter((startIso) => {
            const row = byStart.get(startIso) || [];
            const sample = row.find(({ entry }) => entry && entry.end)?.entry;
            if (!sample || !sample.end) {
              return false;
            }
            if (hasWindow) {
              const startM = minutesSinceMidnightInZone(startIso, tz);
              const endM = minutesSinceMidnightInZone(sample.end, tz);
              if (endM < startM || !(startM >= openM && endM <= closeM)) {
                return false;
              }
            }
            if (!n) {
              return false;
            }
            const block = consecutiveBlock(cal, startIso, n);
            if (!block) {
              return false;
            }
            const startM = minutesSinceMidnightInZone(startIso, tz);
            const endBlockM = minutesSinceMidnightInZone(block.end, tz);
            if (endBlockM < startM) {
              return false;
            }
            if (hasWindow && (startM < openM || endBlockM > closeM)) {
              return false;
            }
            return true;
          });

          if (!times.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No time slots for this day.');
            elTimes.appendChild(p);
            return;
          }
          if (!timesOk.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No slots for this duration within your booking hours.');
            elTimes.appendChild(p);
            return;
          }

          timesOk.forEach((startIso) => {
            const row = byStart.get(startIso) || [];
            const hasSelectable = row.some(({ entry }) => isEntrySelectable(entry));
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.dataset.startIso = startIso;
            btn.textContent = new Date(startIso).toLocaleTimeString(undefined, {
              hour: 'numeric',
              minute: '2-digit',
              timeZone: tz,
            });
            if (!hasSelectable) {
              btn.disabled = true;
              btn.className = pillClasses(false, true);
              elTimes.appendChild(btn);
              return;
            }
            const on = ctx.selectedStartIso === startIso;
            btn.className = pillClasses(on, false);
            btn.addEventListener('click', () => {
              ctx.selectedStartIso = startIso;
              const slotN = slotCountForVariation(v, slotMinutesDefault, ctx.durationHours);
              ctx.selectedBlock = slotN ? consecutiveBlock(cal, startIso, slotN) : null;
              elTimes.querySelectorAll('button').forEach((b) => {
                if (b.disabled) {
                  return;
                }
                const isOn = b.dataset.startIso === ctx.selectedStartIso;
                b.className = pillClasses(isOn, false);
              });
              updateSaveState();
            });
            elTimes.appendChild(btn);
          });
        }

        function updateSaveState() {
          const btn = modalRoot.querySelector('[data-cb-cart-save]');
          btn.disabled = !(ctx.selectedBlock && ctx.selectedBlock.start && ctx.selectedBlock.end);
        }

        async function onSave() {
          if (!ctx.selectedBlock || !ctx.orderItemId) {
            return;
          }
          const elStatus = modalRoot.querySelector('[data-cb-cart-status]');
          const btn = modalRoot.querySelector('[data-cb-cart-save]');
          elStatus.textContent = '';
          btn.disabled = true;
          try {
            const res = await fetch(Drupal.url(`court-booking/cart/slot/${ctx.orderItemId}`), {
              method: 'POST',
              credentials: 'same-origin',
              headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': s.csrfToken,
              },
              body: JSON.stringify({
                start: ctx.selectedBlock.start,
                end: ctx.selectedBlock.end,
              }),
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
              elStatus.textContent = data.message || Drupal.t('Could not update booking.');
              btn.disabled = false;
              return;
            }
            window.location.reload();
          } catch (err) {
            elStatus.textContent = Drupal.t('Network error. Try again.');
            btn.disabled = false;
            // eslint-disable-next-line no-console
            console.error(err);
          }
        }

        document.body.addEventListener('click', (e) => {
          const t = e.target.closest('.cb-cart-slot-edit');
          if (!t) {
            return;
          }
          const orderItemId = t.getAttribute('data-cb-order-item-id');
          const variationId = t.getAttribute('data-cb-variation-id');
          if (!orderItemId || !variationId) {
            return;
          }
          const v = variationsById[String(variationId)] || variationsById[Number(variationId)];
          if (!v) {
            return;
          }
          ctx = {
            orderItemId,
            variation: v,
            selectedYmd: null,
            selectedDay: null,
            selectedStartIso: null,
            selectedBlock: null,
            calendars: null,
            visibleYm: '',
            durationHours: 1,
          };
          const startAttr = t.getAttribute('data-cb-slot-start');
          const endAttr = t.getAttribute('data-cb-slot-end');
          if (startAttr && endAttr) {
            const startMs = new Date(startAttr).getTime();
            const endMs = new Date(endAttr).getTime();
            if (endMs > startMs) {
              const hours = Math.round((endMs - startMs) / 3600000);
              ctx.durationHours = Math.max(1, Math.min(maxBookingHours, hours || 1));
            }
            ctx.selectedYmd = ymdInZone(startAttr, siteTimeZoneId);
            if (bookableYmd.has(ctx.selectedYmd)) {
              ctx.selectedDay = dates.find((d) => d.ymd === ctx.selectedYmd) || null;
            } else if (dates.length) {
              ctx.selectedYmd = dates[0].ymd;
              ctx.selectedDay = dates[0];
            } else {
              ctx.selectedDay = null;
            }
            ctx.visibleYm = ctx.selectedYmd ? ctx.selectedYmd.slice(0, 7) : '';
          } else if (dates.length) {
            ctx.selectedYmd = dates[0].ymd;
            ctx.selectedDay = dates[0];
            ctx.visibleYm = ctx.selectedYmd.slice(0, 7);
          }

          ensureModal();
          populateDurationSelect();
          modalRoot.querySelector('[data-cb-cart-duration]').value = String(ctx.durationHours);
          renderDateStrip();
          if (ctx.selectedDay) {
            loadDayData().then(() => {
              if (startAttr && ctx.calendars) {
                const cal = ctx.calendars[String(v.id)];
                const n = slotCountForVariation(v, slotMinutesDefault, ctx.durationHours);
                if (cal && n && isEntrySelectable(calendarEntries(cal).find((e) => e.start === startAttr))) {
                  const block = consecutiveBlock(cal, startAttr, n);
                  if (block && block.end === endAttr) {
                    ctx.selectedStartIso = startAttr;
                    ctx.selectedBlock = block;
                    renderTimes();
                  }
                }
              }
              updateSaveState();
            });
          } else {
            modalRoot.querySelector('[data-cb-cart-status]').textContent = Drupal.t('No bookable dates in range.');
            updateSaveState();
          }
          openModal();
        });
      });
    },
  };
})(Drupal, drupalSettings, once);
