/**
 * @file
 * Court booking: sport, month strip + calendar modal, duration, multi-slot times, pitches.
 */
(function (Drupal, drupalSettings, once) {
  'use strict';

  /**
   * @param {string} iso
   * @param {string} timeZone
   * @returns {string}
   */
  function ymdInZone(iso, timeZone) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(new Date(iso));
    const y = parts.find((p) => p.type === 'year')?.value;
    const m = parts.find((p) => p.type === 'month')?.value;
    const d = parts.find((p) => p.type === 'day')?.value;
    return `${y}-${m}-${d}`;
  }

  /**
   * @param {string} timeZone
   * @returns {string}
   */
  function todayYmd(timeZone) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(new Date());
    const y = parts.find((p) => p.type === 'year')?.value;
    const m = parts.find((p) => p.type === 'month')?.value;
    const d = parts.find((p) => p.type === 'day')?.value;
    return `${y}-${m}-${d}`;
  }

  /**
   * @param {string} hm
   * @returns {number|null}
   */
  function parseHmMinutes(hm) {
    const raw = String(hm || '').trim();
    if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(raw)) {
      return null;
    }
    const [h, min] = raw.split(':').map((x) => parseInt(x, 10));
    return h * 60 + min;
  }

  /**
   * @param {string} iso
   * @param {string} timeZone
   * @returns {number}
   */
  function minutesSinceMidnightInZone(iso, timeZone) {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).formatToParts(new Date(iso));
    const h = parseInt(parts.find((p) => p.type === 'hour')?.value || '0', 10);
    const min = parseInt(parts.find((p) => p.type === 'minute')?.value || '0', 10);
    return h * 60 + min;
  }

  /**
   * @param {object} entry
   * @returns {boolean}
   */
  function isEntrySelectable(entry) {
    if (!entry) {
      return false;
    }
    if (entry.status === 'closed' || entry.booking_window_exceeded) {
      return false;
    }
    return entry.status === 'available' && Number(entry.remaining) > 0;
  }

  /**
   * @param {string|undefined} raw
   * @returns {string}
   */
  function normalizeDrupalTimeZoneId(raw) {
    const str = typeof raw === 'string' ? raw.trim() : '';
    if (!str) {
      return '';
    }
    try {
      Intl.DateTimeFormat(undefined, { timeZone: str }).format(0);
      return str;
    } catch (e) {
      return '';
    }
  }

  /**
   * @param {Record<string, object>} cal
   * @returns {object[]}
   */
  function calendarEntries(cal) {
    if (!cal || typeof cal !== 'object') {
      return [];
    }
    return Object.values(cal);
  }

  /**
   * @param {string} str
   * @returns {string}
   */
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /**
   * @param {string} ym
   * @param {number} delta
   * @returns {string}
   */
  function addMonthsYm(ym, delta) {
    const [y, m] = ym.split('-').map((x) => parseInt(x, 10));
    const d = new Date(Date.UTC(y, m - 1 + delta, 1));
    const yy = d.getUTCFullYear();
    const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
    return `${yy}-${mm}`;
  }

  /**
   * @param {string} ymd
   * @param {string} tz
   * @returns {string}
   */
  function formatMonthYearHeading(ymd, tz) {
    const [y, m, d] = ymd.split('-').map((x) => parseInt(x, 10));
    const utcNoon = Date.UTC(y, m - 1, d, 12, 0, 0);
    return new Intl.DateTimeFormat(undefined, {
      timeZone: tz,
      month: 'short',
      year: 'numeric',
    }).format(new Date(utcNoon));
  }

  /**
   * @param {number} year
   * @param {number} monthIndex0
   * @returns {string}
   */
  function modalMonthLongLabel(year, monthIndex0) {
    const utcNoon = Date.UTC(year, monthIndex0, 15, 12, 0, 0);
    return new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(new Date(utcNoon));
  }

  /**
   * @param {object} v
   * @param {number} slotMinutesDefault
   * @param {number} durationHours
   * @returns {number|null}
   */
  function slotCountForVariation(v, slotMinutesDefault, durationHours) {
    const slotLen = Math.max(1, Number(v.slotMinutes) || slotMinutesDefault);
    const totalMin = durationHours * 60;
    if (totalMin % slotLen !== 0) {
      return null;
    }
    return totalMin / slotLen;
  }

  /**
   * @param {object} cal
   * @param {string} startIso
   * @param {number} slotCount
   * @returns {{start: string, end: string}|null}
   */
  function consecutiveBlock(cal, startIso, slotCount) {
    let cur = startIso;
    let lastEnd = null;
    for (let i = 0; i < slotCount; i++) {
      const entry = calendarEntries(cal).find((e) => e.start === cur);
      if (!entry || !isEntrySelectable(entry)) {
        return null;
      }
      lastEnd = entry.end;
      cur = entry.end;
    }
    return lastEnd ? { start: startIso, end: lastEnd } : null;
  }

  /**
   * @param {object} v
   * @param {number} hours
   * @returns {string}
   */
  function formatPriceForDuration(v, hours) {
    if (v.priceAmount !== '' && v.priceAmount !== undefined && v.priceCurrencyCode) {
      const num = Number(v.priceAmount);
      if (!Number.isNaN(num)) {
        return new Intl.NumberFormat(undefined, {
          style: 'currency',
          currency: v.priceCurrencyCode,
        }).format(num * hours);
      }
    }
    return v.price || '';
  }

  Drupal.behaviors.courtBooking = {
    attach(context) {
      once('court-booking', '.court-booking-page', context).forEach((root) => {
        const s = drupalSettings.courtBooking;
        if (!s || !Array.isArray(s.sports)) {
          return;
        }

        const elSports = root.querySelector('#cb-sports');
        const elDates = root.querySelector('#cb-dates');
        const elTimes = root.querySelector('#cb-times');
        const elCourts = root.querySelector('#cb-courts');
        const elStatus = root.querySelector('#cb-status');
        const elMonthYear = root.querySelector('#cb-month-year');
        const elStripPrev = root.querySelector('#cb-strip-prev');
        const elStripNext = root.querySelector('#cb-strip-next');
        const elCalOpen = root.querySelector('#cb-cal-open');
        const elDuration = root.querySelector('#cb-duration');
        const elModal = root.querySelector('#cb-modal');
        const elModalBackdrop = root.querySelector('#cb-modal-backdrop');
        const elModalDialog = root.querySelector('#cb-modal-dialog');
        const elCalClose = root.querySelector('#cb-cal-close');
        const elCalPrev = root.querySelector('#cb-cal-prev');
        const elCalNext = root.querySelector('#cb-cal-next');
        const elCalMonthLabel = root.querySelector('#cb-cal-month-label');
        const elCalGrid = root.querySelector('#cb-cal-grid');
        const elCalApply = root.querySelector('#cb-cal-apply');

        const dates = Array.isArray(s.dates) ? s.dates : [];
        const siteTimeZoneId = normalizeDrupalTimeZoneId(s.timezone) || 'UTC';
        const slotMinutesDefault = Math.max(1, parseInt(String(s.slotMinutes || 60), 10));
        const maxBookingHours = Math.max(1, Math.min(24, parseInt(String(s.maxBookingHours || 4), 10)));
        const firstDayOfWeek = Math.max(0, Math.min(6, parseInt(String(s.firstDayOfWeek ?? 0), 10)));

        const bookableYmd = new Set(dates.map((d) => d.ymd));

        /** @type {string|null} */
        let sportId = null;
        /** @type {string|null} */
        let selectedYmd = null;
        /** @type {{ymd: string, from: string, to: string}|null} */
        let selectedDay = null;
        /** @type {string|null} */
        let selectedStartIso = null;
        /** @type {Record<string, object>|null} */
        let calendars = null;
        /** @type {string} yyyy-mm */
        let visibleYm = '';
        /** @type {number} */
        let durationHours = 1;
        /** @type {{year: number, month0: number}} */
        let modalView = { year: new Date().getFullYear(), month0: new Date().getMonth() };
        /** @type {string|null} */
        let modalPendingYmd = null;
        /** @type {Element|null} */
        let focusBeforeModal = null;

        function setStatus(msg) {
          if (!elStatus) {
            return;
          }
          elStatus.textContent = msg || '';
        }

        function pillClasses(on, disabled) {
          const base =
            'rounded-full border px-4 py-2 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E] focus-visible:ring-offset-2';
          if (disabled) {
            return `${base} cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400`;
          }
          if (on) {
            return `${base} border-[#02216E] bg-[#02216E] text-white`;
          }
          return `${base} border-slate-300 bg-white text-slate-800 hover:border-[#02216E]`;
        }

        function updateMonthYearLabel() {
          if (!elMonthYear) {
            return;
          }
          if (selectedYmd) {
            elMonthYear.textContent = formatMonthYearHeading(selectedYmd, siteTimeZoneId).toUpperCase();
          } else if (visibleYm) {
            const [y, m] = visibleYm.split('-').map((x) => parseInt(x, 10));
            const ymd = `${y}-${String(m).padStart(2, '0')}-01`;
            elMonthYear.textContent = formatMonthYearHeading(ymd, siteTimeZoneId).toUpperCase();
          } else {
            elMonthYear.textContent = '';
          }
        }

        function daysInVisibleMonth() {
          return dates.filter((d) => d.ymd.slice(0, 7) === visibleYm);
        }

        function selectDay(day) {
          if (!day) {
            return;
          }
          selectedYmd = day.ymd;
          selectedDay = { ymd: day.ymd, from: day.from, to: day.to };
          selectedStartIso = null;
          visibleYm = day.ymd.slice(0, 7);
          renderDateStrip();
          updateMonthYearLabel();
          elTimes.innerHTML = '';
          elCourts.innerHTML = '';
          loadDayData();
        }

        function populateDurationSelect() {
          if (!elDuration) {
            return;
          }
          elDuration.innerHTML = '';
          for (let h = 1; h <= maxBookingHours; h++) {
            const opt = document.createElement('option');
            opt.value = String(h);
            opt.textContent =
              h === 1
                ? Drupal.t('1 Hour')
                : Drupal.t('@n Hours', { '@n': String(h) });
            elDuration.appendChild(opt);
          }
          elDuration.value = '1';
        }

        function renderSports() {
          elSports.innerHTML = '';
          s.sports.forEach((sport) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.setAttribute('role', 'tab');
            btn.setAttribute('aria-pressed', 'false');
            btn.className = pillClasses(false, false);
            btn.textContent = sport.label;
            btn.dataset.sportId = sport.id;
            btn.addEventListener('click', () => {
              sportId = sport.id;
              selectedStartIso = null;
              calendars = null;
              elSports.querySelectorAll('button').forEach((b) => {
                const on = b.dataset.sportId === sportId;
                b.setAttribute('aria-pressed', on ? 'true' : 'false');
                b.className = pillClasses(on, false);
              });
              elTimes.innerHTML = '';
              elCourts.innerHTML = '';
              setStatus('');
              if (selectedYmd && bookableYmd.has(selectedYmd)) {
                selectedDay = dates.find((d) => d.ymd === selectedYmd) || null;
                visibleYm = selectedYmd.slice(0, 7);
                renderDateStrip();
                updateMonthYearLabel();
                if (selectedDay) {
                  loadDayData();
                }
              } else if (dates.length) {
                visibleYm = dates[0].ymd.slice(0, 7);
                renderDateStrip();
                updateMonthYearLabel();
                selectDay(daysInVisibleMonth()[0] || dates[0]);
              }
            });
            elSports.appendChild(btn);
          });
          if (s.sports.length) {
            const want = s.initialSportId ? String(s.initialSportId) : '';
            const match = want && s.sports.some((sp) => String(sp.id) === want);
            sportId = match ? want : s.sports[0].id;
            elSports.querySelectorAll('button').forEach((b) => {
              const on = b.dataset.sportId === sportId;
              b.setAttribute('aria-pressed', on ? 'true' : 'false');
              b.className = pillClasses(on, false);
            });
          }
        }

        function renderDateStrip() {
          elDates.innerHTML = '';
          if (!dates.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No bookable dates in the current range.');
            elDates.appendChild(p);
            return;
          }
          if (!visibleYm) {
            visibleYm = dates[0].ymd.slice(0, 7);
          }
          const slice = daysInVisibleMonth();
          if (!slice.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No dates in this month. Use the arrows or calendar.');
            elDates.appendChild(p);
            return;
          }
          slice.forEach((day) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.setAttribute('role', 'listitem');
            btn.dataset.ymd = day.ymd;
            const on = day.ymd === selectedYmd;
            btn.className = on
              ? 'min-w-[4.5rem] shrink-0 rounded-xl border-2 border-[#02216E] bg-[#02216E] px-3 py-3 text-center text-white shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]'
              : 'min-w-[4.5rem] shrink-0 rounded-xl border border-slate-200 bg-white px-3 py-3 text-center text-slate-800 shadow-sm hover:border-[#02216E] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]';
            btn.innerHTML = `<span class="block text-xs font-medium uppercase ${on ? 'text-white' : 'text-slate-500'}">${escapeHtml(
              day.weekday || '',
            )}</span><span class="mt-1 block font-display text-lg font-semibold">${escapeHtml(
              String(day.dayNum || ''),
            )}</span>`;
            btn.addEventListener('click', () => {
              selectDay(day);
            });
            elDates.appendChild(btn);
          });
        }

        function currentSport() {
          return s.sports.find((sp) => sp.id === sportId);
        }

        async function fetchCalendar(vid, fromIso, toIso) {
          const interval = encodeURIComponent(s.slotInterval || 'PT60M');
          const url = `${Drupal.url(`commerce-bat/availability/${vid}`)}?from=${encodeURIComponent(
            fromIso,
          )}&to=${encodeURIComponent(toIso)}&interval=${interval}`;
          const res = await fetch(url, { credentials: 'same-origin' });
          if (!res.ok) {
            throw new Error(`Availability HTTP ${res.status}`);
          }
          return res.json();
        }

        async function loadDayData() {
          const sport = currentSport();
          if (!sport || !selectedDay) {
            return;
          }
          setStatus(Drupal.t('Loading availability…'));
          elTimes.innerHTML = '';
          elCourts.innerHTML = '';
          const fromIso = selectedDay.from;
          const toIso = selectedDay.to;

          try {
            const results = await Promise.all(
              sport.variations.map(async (v) => {
                const cal = await fetchCalendar(v.id, fromIso, toIso);
                return [String(v.id), cal];
              }),
            );
            calendars = Object.fromEntries(results);
            renderTimesForDay();
            setStatus('');
          } catch (e) {
            setStatus(Drupal.t('Could not load availability. Please refresh.'));
            // eslint-disable-next-line no-console
            console.error(e);
          }
        }

        function renderTimesForDay() {
          elTimes.innerHTML = '';
          if (!calendars || !selectedYmd) {
            return;
          }
          const tz = siteTimeZoneId;
          const byStart = new Map();
          Object.keys(calendars).forEach((vid) => {
            calendarEntries(calendars[vid]).forEach((entry) => {
              if (!entry.start) {
                return;
              }
              if (ymdInZone(entry.start, tz) !== selectedYmd) {
                return;
              }
              if (!byStart.has(entry.start)) {
                byStart.set(entry.start, []);
              }
              byStart.get(entry.start).push({ vid, entry });
            });
          });
          const times = Array.from(byStart.keys()).sort();
          const openM = parseHmMinutes(s.bookingDayStart);
          const closeM = parseHmMinutes(s.bookingDayEnd);
          const hasWindow = openM !== null && closeM !== null && closeM > openM;

          const sport = currentSport();
          const timesInWindow = times.filter((startIso) => {
            const row = byStart.get(startIso) || [];
            const sample = row.find(({ entry }) => entry && entry.end)?.entry;
            if (!sample || !sample.end) {
              return false;
            }
            if (!hasWindow) {
              /* still need multi-slot fit below */
            } else {
              const startM = minutesSinceMidnightInZone(startIso, tz);
              const endM = minutesSinceMidnightInZone(sample.end, tz);
              if (endM < startM) {
                return false;
              }
              if (!(startM >= openM && endM <= closeM)) {
                return false;
              }
            }
            if (!sport) {
              return false;
            }
            for (const v of sport.variations) {
              const n = slotCountForVariation(v, slotMinutesDefault, durationHours);
              if (!n) {
                continue;
              }
              const block = consecutiveBlock(calendars[v.id], startIso, n);
              if (!block) {
                continue;
              }
              const startM = minutesSinceMidnightInZone(startIso, tz);
              const endBlockM = minutesSinceMidnightInZone(block.end, tz);
              if (endBlockM < startM) {
                continue;
              }
              if (hasWindow && (startM < openM || endBlockM > closeM)) {
                continue;
              }
              return true;
            }
            return false;
          });

          if (!times.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No time slots for this day.');
            elTimes.appendChild(p);
            return;
          }

          if (!timesInWindow.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No slots for this duration within your booking hours.');
            elTimes.appendChild(p);
            return;
          }

          timesInWindow.forEach((startIso) => {
            const row = byStart.get(startIso) || [];
            const hasSelectable = row.some(({ entry }) => isEntrySelectable(entry));
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.setAttribute('role', 'listitem');
            btn.setAttribute('aria-pressed', 'false');
            btn.textContent = new Date(startIso).toLocaleTimeString(undefined, {
              hour: 'numeric',
              minute: '2-digit',
              timeZone: tz,
            });
            btn.dataset.startIso = startIso;
            if (!hasSelectable) {
              btn.disabled = true;
              btn.className = pillClasses(false, true);
              btn.setAttribute('aria-disabled', 'true');
              btn.title = Drupal.t('Fully booked or not available.');
              elTimes.appendChild(btn);
              return;
            }
            btn.className = pillClasses(false, false);
            btn.addEventListener('click', () => {
              selectedStartIso = startIso;
              elTimes.querySelectorAll('button').forEach((b) => {
                if (b.disabled) {
                  return;
                }
                const on = b.dataset.startIso === selectedStartIso;
                b.setAttribute('aria-pressed', on ? 'true' : 'false');
                b.className = pillClasses(on, false);
              });
              renderCourts(startIso);
            });
            elTimes.appendChild(btn);
          });
        }

        function renderCourts(startIso) {
          elCourts.innerHTML = '';
          if (!startIso || !calendars) {
            return;
          }
          const sport = currentSport();
          if (!sport) {
            return;
          }
          const blocks = [];
          sport.variations.forEach((v) => {
            const n = slotCountForVariation(v, slotMinutesDefault, durationHours);
            if (!n) {
              return;
            }
            const block = consecutiveBlock(calendars[v.id], startIso, n);
            if (!block) {
              return;
            }
            blocks.push({ v, block });
          });

          if (!blocks.length) {
            const p = document.createElement('p');
            p.className = 'text-sm text-slate-500';
            p.textContent = Drupal.t('No courts left for this time and duration.');
            elCourts.appendChild(p);
            return;
          }

          blocks.forEach(({ v, block }) => {
            const addVariationToCart = async (triggerEl) => {
              setStatus('');
              if (triggerEl) {
                triggerEl.disabled = true;
              }
              try {
                const res = await fetch(s.addUrl, {
                  method: 'POST',
                  credentials: 'same-origin',
                  headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': s.csrfToken,
                  },
                  body: JSON.stringify({
                    variation_id: v.id,
                    start: block.start,
                    end: block.end,
                    quantity: 1,
                  }),
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) {
                  setStatus(data.message || Drupal.t('Booking failed.'));
                  if (triggerEl) {
                    triggerEl.disabled = false;
                  }
                  return;
                }
                if (data.redirect) {
                  window.location.href = data.redirect;
                }
              } catch (err) {
                setStatus(Drupal.t('Network error. Try again.'));
                if (triggerEl) {
                  triggerEl.disabled = false;
                }
                // eslint-disable-next-line no-console
                console.error(err);
              }
            };

            const card = document.createElement('div');
            card.setAttribute('role', 'listitem');
            const highlight = s.initialVariationId && String(s.initialVariationId) === String(v.id);
            card.className = [
              'flex cursor-pointer flex-col overflow-hidden rounded-2xl border bg-white shadow-sm',
              highlight ? 'border-[#02216E] ring-2 ring-[#02216E] ring-offset-2' : 'border-slate-200',
            ].join(' ');
            card.setAttribute('tabindex', '0');
            card.setAttribute('aria-label', Drupal.t('Book @title', { '@title': v.title }));

            const media = document.createElement('div');
            media.className = 'aspect-[4/3] w-full bg-slate-100 bg-cover bg-center';
            if (v.image) {
              media.style.backgroundImage = `url('${String(v.image).replace(/'/g, '%27')}')`;
            }

            const body = document.createElement('div');
            body.className = 'flex flex-1 flex-col gap-2 p-4';

            const h = document.createElement('h3');
            h.className = 'font-display text-lg font-semibold text-slate-900';
            h.textContent = v.title;

            const price = document.createElement('p');
            price.className = 'text-sm font-semibold text-orange-600';
            price.textContent = formatPriceForDuration(v, durationHours);

            const bookBtn = document.createElement('button');
            bookBtn.type = 'button';
            bookBtn.className =
              'cb-book mt-2 inline-flex items-center justify-center rounded-xl bg-[#02216E] px-4 py-2 text-sm font-semibold text-white hover:bg-[#011550] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]';
            bookBtn.textContent = Drupal.t('Book');

            bookBtn.addEventListener('click', (e) => {
              e.preventDefault();
              e.stopPropagation();
              addVariationToCart(bookBtn);
            });

            card.addEventListener('click', () => {
              addVariationToCart(bookBtn);
            });
            card.addEventListener('keydown', (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                addVariationToCart(bookBtn);
              }
            });

            body.appendChild(h);
            body.appendChild(price);
            body.appendChild(bookBtn);
            card.appendChild(media);
            card.appendChild(body);
            elCourts.appendChild(card);
          });
        }

        function renderModalCalendar() {
          if (!elCalGrid || !elCalMonthLabel) {
            return;
          }
          const { year, month0 } = modalView;
          elCalMonthLabel.textContent = modalMonthLongLabel(year, month0).toUpperCase();
          elCalGrid.innerHTML = '';

          const first = new Date(Date.UTC(year, month0, 1));
          let startWeekday = first.getUTCDay();
          startWeekday = (startWeekday - firstDayOfWeek + 7) % 7;
          const daysInMo = new Date(Date.UTC(year, month0 + 1, 0)).getUTCDate();

          for (let i = 0; i < startWeekday; i++) {
            const cell = document.createElement('div');
            cell.className = 'h-10';
            elCalGrid.appendChild(cell);
          }

          for (let d = 1; d <= daysInMo; d++) {
            const ymd = `${year}-${String(month0 + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.textContent = String(d);
            btn.className =
              'h-10 rounded-lg text-sm font-semibold focus:outline-none focus-visible:ring-2 focus-visible:ring-[#02216E]';
            const bookable = bookableYmd.has(ymd);
            const isPending = modalPendingYmd === ymd;
            if (!bookable) {
              btn.disabled = true;
              btn.className += ' cursor-not-allowed text-slate-300';
            } else if (isPending) {
              btn.className += ' bg-[#02216E] text-white';
            } else {
              btn.className += ' text-slate-800 hover:bg-sky-50';
            }
            btn.addEventListener('click', () => {
              if (!bookable) {
                return;
              }
              modalPendingYmd = ymd;
              renderModalCalendar();
            });
            elCalGrid.appendChild(btn);
          }
        }

        function openModal() {
          if (!elModal) {
            return;
          }
          focusBeforeModal = document.activeElement;
          if (selectedYmd) {
            const [y, m] = selectedYmd.split('-').map((x) => parseInt(x, 10));
            modalView = { year: y, month0: m - 1 };
          } else if (visibleYm) {
            const [y, m] = visibleYm.split('-').map((x) => parseInt(x, 10));
            modalView = { year: y, month0: m - 1 };
          }
          modalPendingYmd = selectedYmd;
          renderModalCalendar();
          elModal.classList.remove('hidden');
          elModal.setAttribute('aria-hidden', 'false');
          const focusables = getModalFocusables();
          if (focusables.length) {
            focusables[0].focus();
          }
          document.addEventListener('keydown', onModalKeydown);
        }

        function closeModal() {
          if (!elModal) {
            return;
          }
          elModal.classList.add('hidden');
          elModal.setAttribute('aria-hidden', 'true');
          document.removeEventListener('keydown', onModalKeydown);
          if (focusBeforeModal && typeof focusBeforeModal.focus === 'function') {
            focusBeforeModal.focus();
          }
          focusBeforeModal = null;
        }

        function getModalFocusables() {
          if (!elModalDialog) {
            return [];
          }
          return Array.from(
            elModalDialog.querySelectorAll(
              'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
            ),
          );
        }

        function onModalKeydown(e) {
          if (e.key === 'Escape') {
            e.preventDefault();
            closeModal();
            return;
          }
          if (e.key !== 'Tab' || !elModalDialog) {
            return;
          }
          const list = getModalFocusables();
          if (!list.length) {
            return;
          }
          const first = list[0];
          const last = list[list.length - 1];
          if (e.shiftKey) {
            if (document.activeElement === first) {
              e.preventDefault();
              last.focus();
            }
          } else if (document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }

        if (elStripPrev) {
          elStripPrev.addEventListener('click', () => {
            if (!visibleYm) {
              return;
            }
            visibleYm = addMonthsYm(visibleYm, -1);
            const slice = daysInVisibleMonth();
            selectedYmd = null;
            selectedDay = null;
            selectedStartIso = null;
            calendars = null;
            elTimes.innerHTML = '';
            elCourts.innerHTML = '';
            renderDateStrip();
            updateMonthYearLabel();
            if (slice.length) {
              selectDay(slice[0]);
            }
          });
        }

        if (elStripNext) {
          elStripNext.addEventListener('click', () => {
            if (!visibleYm) {
              return;
            }
            visibleYm = addMonthsYm(visibleYm, 1);
            const slice = daysInVisibleMonth();
            selectedYmd = null;
            selectedDay = null;
            selectedStartIso = null;
            calendars = null;
            elTimes.innerHTML = '';
            elCourts.innerHTML = '';
            renderDateStrip();
            updateMonthYearLabel();
            if (slice.length) {
              selectDay(slice[0]);
            }
          });
        }

        if (elCalOpen) {
          elCalOpen.addEventListener('click', () => openModal());
        }
        if (elCalClose) {
          elCalClose.addEventListener('click', () => closeModal());
        }
        if (elModalBackdrop) {
          elModalBackdrop.addEventListener('click', () => closeModal());
        }
        if (elCalPrev) {
          elCalPrev.addEventListener('click', () => {
            const d = new Date(Date.UTC(modalView.year, modalView.month0 - 1, 1));
            modalView = { year: d.getUTCFullYear(), month0: d.getUTCMonth() };
            renderModalCalendar();
          });
        }
        if (elCalNext) {
          elCalNext.addEventListener('click', () => {
            const d = new Date(Date.UTC(modalView.year, modalView.month0 + 1, 1));
            modalView = { year: d.getUTCFullYear(), month0: d.getUTCMonth() };
            renderModalCalendar();
          });
        }
        if (elCalApply) {
          elCalApply.addEventListener('click', () => {
            if (!modalPendingYmd) {
              return;
            }
            const day = dates.find((x) => x.ymd === modalPendingYmd);
            if (!day) {
              return;
            }
            visibleYm = modalPendingYmd.slice(0, 7);
            closeModal();
            selectDay(day);
          });
        }

        if (elDuration) {
          elDuration.addEventListener('change', () => {
            durationHours = Math.max(1, parseInt(elDuration.value, 10) || 1);
            selectedStartIso = null;
            elCourts.innerHTML = '';
            if (calendars && selectedYmd) {
              renderTimesForDay();
            }
          });
        }

        populateDurationSelect();
        renderSports();
        if (dates.length) {
          durationHours = 1;
          const today = todayYmd(siteTimeZoneId);
          if (bookableYmd.has(today)) {
            visibleYm = today.slice(0, 7);
          } else {
            visibleYm = dates[0].ymd.slice(0, 7);
          }
          renderDateStrip();
          updateMonthYearLabel();
          const slice = daysInVisibleMonth();
          const pick = bookableYmd.has(today) ? dates.find((d) => d.ymd === today) : slice[0] || dates[0];
          if (pick) {
            selectDay(pick);
          }
        } else {
          renderDateStrip();
          updateMonthYearLabel();
        }
      });
    },
  };
})(Drupal, drupalSettings, once);
