# Court Booking

Custom booking flow (Twig + vanilla JS) on `/book/amenities`, backed by Commerce BAT JSON availability and server-side add-to-cart validation.

## Requirements

- Drupal Commerce, Commerce Cart, Commerce BAT (lesson mode for courts).
- **Misk** theme: run Tailwind from `web/themes/custom/misk` so **court_booking** Twig and JS are scanned (`tailwind.config.js` uses `../../../modules/custom/court_booking/...` from that folder).  
  `cd web/themes/custom/misk && npm ci && npm run build`
- **Misk** loads `dist/misk.css` with **`preprocess: false`** so Drupal’s CSS aggregation does not serve a stale bundle after you rebuild Tailwind. If styles still look wrong, run `drush cr` and confirm `/themes/custom/misk/dist/misk.css` loads in the browser network tab.

## Enable

```bash
drush theme:enable misk -y
drush config:set system.theme default misk -y
drush en court_booking -y
drush cr
```

Grant **access court booking page** and **use court booking add** to roles that should book (often anonymous + authenticated). Configure mappings at **Commerce → Configuration → Court booking** (one line per sport: `TERM_ID|VARIATION_ID,VARIATION_ID`).

## Notes

- Add-to-cart forms for **lesson** BAT variations hide `field_cbat_rental_date` and link users to the booking page; products with mapped variations get a **Book a court** CTA.
