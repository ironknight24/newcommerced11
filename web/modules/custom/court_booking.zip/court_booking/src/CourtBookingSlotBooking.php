<?php

namespace Drupal\court_booking;

use Drupal\commerce_bat\Availability\AvailabilityManagerInterface;
use Drupal\commerce_bat\Util\DateTimeHelper;
use Drupal\commerce_order\Entity\OrderItemInterface;
use Drupal\commerce_product\Entity\ProductVariationInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Validates lesson slots and applies rental + scaled unit price to order items.
 */
final class CourtBookingSlotBooking {

  use StringTranslationTrait;

  public function __construct(
    protected AvailabilityManagerInterface $availabilityManager,
    protected ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * Parses and validates a lesson slot for booking (add-to-cart or cart update).
   *
   * @return array{
   *   ok: bool,
   *   status: int,
   *   message: string,
   *   start?: \DateTimeImmutable,
   *   end?: \DateTimeImmutable,
   *   diff_minutes?: int,
   *   billing_units?: int,
   *   slot_len_minutes?: int
   * }
   */
  public function validateLessonSlot(
    ProductVariationInterface $variation,
    string $start_raw,
    string $end_raw,
    int $quantity,
    AccountInterface $account,
  ): array {
    $fail = function (int $status, string $message) {
      return [
        'ok' => FALSE,
        'status' => $status,
        'message' => $message,
      ];
    };

    $bat_mode = $this->availabilityManager->getModeForVariation($variation);
    if ($bat_mode !== 'lesson') {
      if ($bat_mode === NULL) {
        return $fail(400, (string) $this->t('This court variation is not configured for BAT lesson booking.'));
      }
      return $fail(400, (string) $this->t('This product does not use lesson booking.'));
    }

    try {
      $start = DateTimeHelper::normalizeUtc(DateTimeHelper::parseUtc($start_raw, FALSE));
      $end = DateTimeHelper::normalizeUtc(DateTimeHelper::parseUtc($end_raw, FALSE));
    }
    catch (\Throwable $e) {
      return $fail(400, (string) $this->t('Invalid date format.'));
    }

    $cb_config = $this->configFactory->get('court_booking.settings');
    $slot_len_minutes = max(1, (int) $this->availabilityManager->getLessonSlotLength($variation));
    $diff_sec = $end->getTimestamp() - $start->getTimestamp();
    if ($diff_sec <= 0) {
      return $fail(400, (string) $this->t('End time must be after start time.'));
    }
    $diff_minutes = (int) floor($diff_sec / 60);
    if ($diff_minutes % $slot_len_minutes !== 0) {
      return $fail(400, (string) $this->t('Booking length must be a multiple of @m minutes.', ['@m' => $slot_len_minutes]));
    }
    $max_hours = max(1, min(24, (int) ($cb_config->get('max_booking_hours') ?: 4)));
    if ($diff_minutes > $max_hours * 60) {
      return $fail(400, (string) $this->t('Booking cannot exceed @h hours.', ['@h' => $max_hours]));
    }
    $site_tz = CourtBookingRegional::effectiveTimeZoneId($this->configFactory, $account);
    if (!$this->slotWithinConfiguredHours(
      $start,
      $end,
      $site_tz,
      (string) ($cb_config->get('booking_day_start') ?: '06:00'),
      (string) ($cb_config->get('booking_day_end') ?: '23:00'),
    )) {
      return $fail(400, (string) $this->t('That time is outside the allowed booking hours.'));
    }

    if (!$this->availabilityManager->isAvailable($variation, $start, $end, $quantity)) {
      return $fail(409, (string) $this->t('That slot is no longer available.'));
    }

    $billing_units = (int) ($diff_minutes / $slot_len_minutes);

    return [
      'ok' => TRUE,
      'status' => 200,
      'message' => '',
      'start' => $start,
      'end' => $end,
      'diff_minutes' => $diff_minutes,
      'billing_units' => $billing_units,
      'slot_len_minutes' => $slot_len_minutes,
    ];
  }

  /**
   * Sets rental field and overridden unit price from slot length.
   */
  public function applyRentalAndPrice(
    OrderItemInterface $order_item,
    ProductVariationInterface $variation,
    \DateTimeImmutable $start,
    \DateTimeImmutable $end,
    int $billing_units,
  ): void {
    if ($order_item->hasField('field_cbat_rental_date')) {
      $order_item->set('field_cbat_rental_date', [
        'value' => DateTimeHelper::formatUtc($start),
        'end_value' => DateTimeHelper::formatUtc($end),
      ]);
    }
    $base_price = $variation->getPrice();
    if ($base_price && $billing_units >= 1) {
      $scaled = $base_price->multiply((string) $billing_units);
      $order_item->setUnitPrice($scaled, TRUE);
    }
  }

  /**
   * TRUE if local start/end fall inside the configured HH:MM window (site TZ).
   */
  public function slotWithinConfiguredHours(
    \DateTimeImmutable $start,
    \DateTimeImmutable $end,
    string $timezone_id,
    string $open_hm,
    string $close_hm,
  ): bool {
    $open_m = $this->parseHmToMinutes($open_hm);
    $close_m = $this->parseHmToMinutes($close_hm);
    if ($open_m === NULL || $close_m === NULL || $close_m <= $open_m) {
      return TRUE;
    }
    try {
      $tz = new \DateTimeZone($timezone_id);
    }
    catch (\Throwable $e) {
      $tz = new \DateTimeZone('UTC');
    }
    $start_local = $start->setTimezone($tz);
    $end_local = $end->setTimezone($tz);
    $start_m = (int) $start_local->format('G') * 60 + (int) $start_local->format('i');
    $end_m = (int) $end_local->format('G') * 60 + (int) $end_local->format('i');
    if ($end_m < $start_m) {
      return FALSE;
    }

    return $start_m >= $open_m && $end_m <= $close_m;
  }

  /**
   * Parses HH:MM to minutes from midnight, or NULL if invalid.
   */
  public function parseHmToMinutes(string $value): ?int {
    $raw = trim($value);
    if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $raw)) {
      return NULL;
    }
    [$h, $m] = array_map('intval', explode(':', $raw, 2));

    return $h * 60 + $m;
  }

}
