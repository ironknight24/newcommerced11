<?php

namespace Drupal\court_booking\Form;

use Drupal\commerce_product\Entity\Product;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure sport → product or variation mappings and booking page options.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'court_booking_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['court_booking.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('court_booking.settings');

    $lines = [];
    foreach ($config->get('sport_mappings') ?: [] as $row) {
      $tid = (int) ($row['sport_tid'] ?? 0);
      $pid = (int) ($row['product_id'] ?? 0);
      $vids = array_map('intval', $row['variation_ids'] ?? []);
      if ($tid && $pid > 0) {
        $lines[] = $tid . '|p:' . $pid;
      }
      elseif ($tid && $vids) {
        $lines[] = $tid . '|' . implode(',', $vids);
      }
    }

    $form['sport_vocabulary'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Sport vocabulary machine name'),
      '#default_value' => $config->get('sport_vocabulary') ?: 'court_type',
      '#description' => $this->t('Used to load labels for configured sport term IDs (optional display only).'),
      '#required' => TRUE,
    ];

    $form['sport_mapping_lines'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Sport term → product or variations'),
      '#default_value' => implode("\n", $lines),
      '#rows' => 8,
      '#description' => $this->t('One mapping per line. Use <code>TERM_ID|p:PRODUCT_ID</code> to book all published variations on that Commerce product (recommended: one product per sport). Use <code>TERM_ID|VID,VID</code> for explicit variation IDs. Example: <code>3|p:12</code> or <code>3|10,11</code>. Lines starting with # are ignored.'),
      '#required' => FALSE,
    ];

    $form['days_ahead'] = [
      '#type' => 'number',
      '#title' => $this->t('Days ahead on date strip'),
      '#default_value' => (int) ($config->get('days_ahead') ?: 60),
      '#min' => 1,
      '#max' => 365,
      '#required' => TRUE,
    ];

    $days = [
      0 => $this->t('Sunday'),
      1 => $this->t('Monday'),
      2 => $this->t('Tuesday'),
      3 => $this->t('Wednesday'),
      4 => $this->t('Thursday'),
      5 => $this->t('Friday'),
      6 => $this->t('Saturday'),
    ];
    $excluded_raw = array_values(array_unique(array_map('intval', $config->get('excluded_weekdays') ?: [])));
    $excluded_default = !empty($excluded_raw) ? array_combine($excluded_raw, $excluded_raw) : [];
    $form['excluded_weekdays'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Excluded weekdays (greyed on date strip)'),
      '#options' => $days,
      '#default_value' => $excluded_default,
    ];

    $form['booking_hours'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Daily booking hours'),
      '#description' => $this->t('Opening/closing are interpreted in each visitor’s effective timezone from <a href=":url">Regional settings</a> (default time zone, optional per-user time zone), same as the booking date strip and slot labels.', [
        ':url' => '/admin/config/regional/settings',
      ]),
    ];
    $form['booking_hours']['booking_day_start'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Opening time'),
      '#default_value' => $config->get('booking_day_start') ?: '06:00',
      '#size' => 8,
      '#maxlength' => 5,
      '#required' => TRUE,
      '#description' => $this->t('24-hour format, e.g. 06:00'),
    ];
    $form['booking_hours']['booking_day_end'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Closing time'),
      '#default_value' => $config->get('booking_day_end') ?: '23:00',
      '#size' => 8,
      '#maxlength' => 5,
      '#required' => TRUE,
      '#description' => $this->t('Last moment a slot may end (e.g. 23:00 for hourly slots through 22:00–23:00).'),
    ];

    $form['order_type_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Cart order type ID'),
      '#default_value' => $config->get('order_type_id') ?: 'default',
      '#required' => TRUE,
    ];

    $form['max_booking_hours'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum booking duration (hours)'),
      '#default_value' => (int) ($config->get('max_booking_hours') ?: 4),
      '#min' => 1,
      '#max' => 24,
      '#required' => TRUE,
      '#description' => $this->t('Upper limit for a single add-to-cart request. The amenities page duration dropdown offers 1 through this value. The slot length comes from Commerce BAT lesson settings.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    foreach (['booking_day_start', 'booking_day_end'] as $key) {
      $raw = trim((string) $form_state->getValue($key));
      if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $raw)) {
        $form_state->setErrorByName($key, $this->t('Use 24-hour time as HH:MM (e.g. 06:00 or 23:00).'));
      }
    }
    $start = $this->parseHm($form_state->getValue('booking_day_start'));
    $end = $this->parseHm($form_state->getValue('booking_day_end'));
    if ($start !== NULL && $end !== NULL && $end <= $start) {
      $form_state->setErrorByName('booking_day_end', $this->t('Closing time must be after opening time.'));
    }

    $maxH = (int) $form_state->getValue('max_booking_hours');
    if ($maxH < 1 || $maxH > 24) {
      $form_state->setErrorByName('max_booking_hours', $this->t('Maximum booking duration must be between 1 and 24 hours.'));
    }

    $text = trim((string) $form_state->getValue('sport_mapping_lines'));
    if ($text === '') {
      return;
    }
    foreach (preg_split('/\R/', $text) as $line) {
      $line = trim($line);
      if ($line === '' || str_starts_with($line, '#')) {
        continue;
      }
      if (!str_contains($line, '|')) {
        $form_state->setErrorByName('sport_mapping_lines', $this->t('Each non-empty line must contain a pipe: TERM_ID|p:PRODUCT_ID or TERM_ID|VID,...'));
        return;
      }
      [$tid, $rest] = array_map('trim', explode('|', $line, 2));
      if (!ctype_digit($tid)) {
        $form_state->setErrorByName('sport_mapping_lines', $this->t('Invalid term ID in line: @line', ['@line' => $line]));
        return;
      }
      if (preg_match('/^p:(\d+)$/i', $rest, $m)) {
        $product = Product::load((int) $m[1]);
        if (!$product) {
          $form_state->setErrorByName('sport_mapping_lines', $this->t('Commerce product not found for line: @line', ['@line' => $line]));
          return;
        }
        continue;
      }
      foreach (preg_split('/\s*,\s*/', $rest, -1, PREG_SPLIT_NO_EMPTY) as $vid) {
        if (!ctype_digit($vid)) {
          $form_state->setErrorByName('sport_mapping_lines', $this->t('Invalid variation ID in line: @line', ['@line' => $line]));
          return;
        }
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $mappings = [];
    $text = trim((string) $form_state->getValue('sport_mapping_lines'));
    if ($text !== '') {
      foreach (preg_split('/\R/', $text) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
          continue;
        }
        [$tid, $rest] = array_map('trim', explode('|', $line, 2));
        if (preg_match('/^p:(\d+)$/i', $rest, $m)) {
          $mappings[] = [
            'sport_tid' => (int) $tid,
            'product_id' => (int) $m[1],
            'variation_ids' => [],
          ];
          continue;
        }
        $ids = [];
        foreach (preg_split('/\s*,\s*/', $rest, -1, PREG_SPLIT_NO_EMPTY) as $vid) {
          $ids[] = (int) $vid;
        }
        $mappings[] = [
          'sport_tid' => (int) $tid,
          'product_id' => 0,
          'variation_ids' => $ids,
        ];
      }
    }

    $excluded = [];
    foreach ($form_state->getValue('excluded_weekdays') ?: [] as $wday => $on) {
      if ($on) {
        $excluded[] = (int) $wday;
      }
    }
    $excluded = array_values(array_unique($excluded));

    $this->config('court_booking.settings')
      ->set('sport_vocabulary', $form_state->getValue('sport_vocabulary'))
      ->set('sport_mappings', $mappings)
      ->set('days_ahead', (int) $form_state->getValue('days_ahead'))
      ->set('excluded_weekdays', $excluded)
      ->set('booking_day_start', trim((string) $form_state->getValue('booking_day_start')))
      ->set('booking_day_end', trim((string) $form_state->getValue('booking_day_end')))
      ->set('order_type_id', $form_state->getValue('order_type_id'))
      ->set('max_booking_hours', max(1, min(24, (int) $form_state->getValue('max_booking_hours'))))
      ->save();

    parent::submitForm($form, $form_state);
  }

  /**
   * Parses HH:MM to minutes from midnight.
   */
  private function parseHm(mixed $value): ?int {
    $raw = trim((string) $value);
    if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $raw)) {
      return NULL;
    }
    [$h, $m] = array_map('intval', explode(':', $raw, 2));

    return $h * 60 + $m;
  }

}
